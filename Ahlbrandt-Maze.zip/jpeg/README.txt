This JPEG source code is based on release 8b of the JPEG library
(16-May-2010) written by the Independent JPEG Group (http://www.ijg.org).

To simplify the compilation process with C++ programs, I have 
renamed all of their *.c files to *.cpp.  I also removed the
following source files to avoid compilation conflicts: ansi2knr.c 
cjpeg.c ckconfig.c djpeg.c example.c jmemansi.c jmemdos.c jmemmac.c 
jmemname.c jpegtran.c main.c rdjpgcom.c rdrle.c wrjpgcom.c wrrle.c.

The libjpeg.a library is compiled using "make" on most Linux 
systems and on Apple OS X systems.  I don't know about other platforms.

John Gauch
December 2010
