//============================================================
//  File:       im_float.cpp
//  Author:     John Gauch
//  Date:       Spring 2009 - Fall 2016
//============================================================

#include "im_float.h"
#include "../jpeg/jpeg.h"
#include "im_pixel.cpp"
